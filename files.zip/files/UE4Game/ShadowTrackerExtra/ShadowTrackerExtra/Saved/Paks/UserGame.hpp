SystemConfig=true
DamageConfig=true
StabilityWeapon=true
Configjson=true

[/Script/ShadowTrackerExtra.ShootWeaponEntity]
+bAddOwnerOffsetVelocity=true
+bAutoReload=true
+bAutoExitScopeAfterFire=true
+IsSupportAutoAim=true
+RecoilKickADS=9999999864000.90f(true)
+AnimationKick=9999999864000.90f(true)
+GameDeviationFactor=9999999864000.90f(true)
+GameDeviationAccuracy=9999999864000.90f(true)
+AccessoriesRecoveryFactor=9999999864000.90f(true)
+AccessoriesDeviationFactor=9999999864000.90f(true)
+AccessoriesHRecoilFactor=9999999864000.90f(true)
+AccessoriesVRecoilFactor=9999999864000.90f(true)
+ShotGunCenterPerc=Max
+ShotGunVerticalSpread=Max
+ShotGunHorizontalSpread=Max
+ExtraHitPerformScale=Max
+CrossHairInitSize=9999999864000.90f
+CrossHairBurstSpeed=9999999864000.90f
+CrossHairBurstIncreaseSpeed=9999999864000.90f
+BulletFireSpeed=909090
+WeaponAimInTime=0.001f
+WeaponWarnUpTime=0.001f
+PreFireTime=0.0001f
+PostFireTime=0.0001f
+PostReloadTime=0.0001f
+ReloadTime=0.0001f
+ForegripParam=99999864.0
.ForegripParam=99999864.0
+MagParam=99999864.0
.MagParam=99999864.0
+ShootInterval=99999864.0
+WeaponAimPitchRate=99999864.0
+WeaponAimYawRate=99999864.0
+GameMotionYawRate=99999864.0
+GameMotionPitchRate=99999864.0
+SensitiveFireYawRate=99999864.0
+SensitiveFirePitchRate=99999864.0

[/Script/ShadowTrackerExtra.STExtraBaseCharacter]
EnableStatesInterruptRPC=true
HitBoxJudgment=9999998640(true)
DSHitPartJudgment=9999998640(true)
UseShotsVerifyEx=true
UseAimAssist=9999998640
UseRecoilFaktor=false
UseCameraEx=false
UnityWeaponUnit=9999998640
InstanHitWeapon=true
bEnableCompVisionOptimization=true
UseAvatarComponent2=false
UseAvatarComponent=true
bUsePoseStateOfflineCheck=true
bEnableDebugServiceInfo=false
bCausedByWorld=9999998640
CharacterAnimEventDelegate=Max
OnPushDamageDynamicDelegate=Max
OnTakeDamageDynamicDelegate=Max
bScaleMomentumByMass=9999998640
bRadialDamageVelChange=false
DamageImpulse=9999998640
DestructibleImpulse=99999864000
DestructibleDamageSpreadScale=99999864000
DamagePartJudgment=99999864000

[/Script/ShadowTrackerExtra.AntiCheatConfig]
nill
null
exit
exits

[/Script/ShadowTrackerExtra.SaveGame]
nill
null
exit
exits

[/Script/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*]
14680=true
14685=true

[WeaponRecoilConfig]
r.VerticalRecoilMin=0
r.VerticalRecoilMax=0
r.VerticalRecoilRecoveryMin=0
r.VerticalRecoilVariation=0
r.VerticalRecoveryModifier=0
r.VerticalRecoveryClamp=0
r.VerticalRecoveryMax=0
r.LeftMax=0
r.RightMax=0
r.VehicleRecoilScalar=0

[/Script/ShadowTrackerExtra.PartHitComponent]
UpdateHitBoxDeltaTime=true
bActivePartHit=true
bDebugCollisionLine=true
GetCurHitPartJugementType=9999999864000×10000(true)
HitPartJugementTypeWeapon=10000(true)
UpdateHitBoxDeltaTime=true

[/Script/ShadowTrackerExtra.STCharacterMovementComponent]
UseVelocityDirMinSpeed=9.9f
JumpFloorZ=1200

[/Script/ShadowTrackerExtra.DamageType]
DestructibleDamageSpreadScale=9999999864000,90000(true)
DamageImpulse=9999999864000,90000(true)
bRadialDamageVelChange=10000
bCausedByWorld=true
bScaleMomentumByMass=10000(true)
bScaleWeaponshotsMomentumByMass=9000(true)
r.DestructibleDamageSpreadScale=9.9f
bDestructibleImpulse=9999999864000.9f
bDamageFalloff=100.0f
bDamageImpulse=9.9f
r.RadialDamageVelChange=true
r.CausedByWorld=true
r.ScaleMomentumByMass=true
r.CausedByWorld=9999
r.ScaleMomentumByMass=9999
r.RadialDamageVelChange=9999
r.DamageImpulse=999.1
HitPartDestructibleDamageSpreadScale=9.9f

[/Script/ShadowTrackerExtra.AlTargetInViewOffset]
bTargetInViewDueToOffset=999999

[/Script/ShadowTrackerExtra.STExtraPlayerController]
+AutoScopeAimTraceDistance=90000.0f
+CanMoveCDTime=0.00009
+CanSprintCDTime=0.000009
+SwitchPoseCDTime=0.000009
+MovealbeSwitchPoseTime=0.000009
+bIsAutoAimEnabled=true
+bIsMeleeAutoAimEnabled=true
+IsDeadForLogout=false
+bIsAutoAimOnlyInTouch=true
+bIsAutoAimOnlyOnFire=true
+bMoveInMiniMap=true
+bAutoSprint=true
+IsCurrentSpectatorFreeView=0
+isPressingBtn_AimAndFire=true
+DiedisableInput=false
+bShowWhoObservingMe=0
+IsCharacterInitFlushStreaming=true
+IsAutoGetCircleInfo=true
+bEnableOBBulletTrackEffect=true
+bEnableOBBulletTrackEffectSetting=true
+bAddMovementTickInSpect=false
+IsCanViewEnemy=true
+AutoSelectViewTarget=true

[/Script/ShadowTrackerExtra.MovementComponent]
GetMaxSpeed=9999999864000+999

[/Script/ShadowTrackerExtra.ClothPhysicsProperties_Legacy]#DVGENT
GravityScale=120.0f

[/Script/ShadowTrackerExtra.STExtraGameInstance]
+SwitchesInMaps=(MapName="shooting_range4",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="PUBG_Forest",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="PUBG_Desert",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="PUBG_Savage_Main",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="DihorOtok_Main",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="TD_Logging_Camp_Main",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="PVE_Infection_main",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="HP_City_Main",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="TD_Ruins_Half",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="TD_Factory_Depot_Mian",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="VehicleBattle_TDM_PUBG_Forest",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="SocialIsland_Main",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="SocialIsland_Private_Main",Switches=((Key="t.MaxFPS",Value="60")))
+RenderStyleParamsInMaps=(DynamicStyleName=ERenderDynamicStyle::Default, PostProcessParams=("ColorSaturation|(X=2.300000,Y=2.300000,Z=2.300000,W=2.300000)"), ACESParams=(TintColor=(R=1.000000,G=1.000000,B=1.000000,A=1.000000),Bright=0.500000,Gray=1.00000,ShoulderStrength=2.330000,ToeStrength=0.140000,LinearStrength=0.500000,LinearAngle=0.060000))
+MobileMSAAOpenConfig=(RenderKey="r.ACESStyle", RenderValue=5)
+MobileMSAAOpenConfig=(RenderKey="t.MaxFPS", RenderValue=60)
+MobileMSAACloseConfig=(RenderKey="r.ACESStyle", RenderValue=5)
+MobileMSAACloseConfig=(RenderKey="t.MaxFPS", RenderValue=60)

[/Script/ShadowTrackerExtra.STExtraPlayerController]
+SwitchesInMaps=(MapName="shooting_range4",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="PUBG_Forest",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="PUBG_Desert",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="PUBG_Savage_Main",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="DihorOtok_Main",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="TD_Logging_Camp_Main",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="PVE_Infection_main",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="HP_City_Main",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="TD_Ruins_Half",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="TD_Factory_Depot_Mian",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="VehicleBattle_TDM_PUBG_Forest",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="SocialIsland_Main",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="SocialIsland_Private_Main",Switches=((Key="t.MaxFPS",Value="60")))
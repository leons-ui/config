SystemConfig=true
DamageConfig=true
StabilityWeapon=true
Configjson=true

[/Script/ShadowTrackerExtra.ShootWeaponEntity]
+bAddOwnerOffsetVelocity=true
+bAutoReload=true
+bAutoExitScopeAfterFire=true
+IsSupportAutoAim=true
+RecoilKickADS=2.0f(true)
+AnimationKick=2.0f(true)
+GameDeviationFactor=2.0f(true)
+GameDeviationAccuracy=2.0f(true)
+AccessoriesRecoveryFactor=2.0f(true)
+AccessoriesDeviationFactor=2.0f(true)
+AccessoriesHRecoilFactor=2.0f(true)
+AccessoriesVRecoilFactor=2.0f(true)
+ShotGunCenterPerc=Max
+ShotGunVerticalSpread=Max
+ShotGunHorizontalSpread=Max
+ExtraHitPerformScale=Max
+CrossHairInitSize=9,0f
+CrossHairBurstSpeed=9,0f
+CrossHairBurstIncreaseSpeed=9,0f
+BulletFireSpeed=909090
+WeaponAimInTime=0.001f
+WeaponWarnUpTime=0.001f
+PreFireTime=0.0001f
+PostFireTime=0.0001f
+PostReloadTime=0.0001f
+ReloadTime=0.0001f
+ForegripParam=9.0099999
.ForegripParam=9.0099999
+MagParam=9.0099999
.MagParam=9.0099999
+ShootInterval=9.0099999
+WeaponAimPitchRate=9.0099999
+WeaponAimYawRate=9.0099999
+GameMotionYawRate=9.0099999
+GameMotionPitchRate=9.0099999
+SensitiveFireYawRate=9.0099999
+SensitiveFirePitchRate=9.0099999

[/Script/ShadowTrackerExtra.STExtraBaseCharacter]
EnableStatesInterruptRPC=true
HitBoxJudgment=99,999(true)
DSHitPartJudgment=99,999(true)
UseShotsVerifyEx=true
UseAimAssist=99,999
UseRecoilFaktor=false
UseCameraEx=false
UnityWeaponUnit=99,999
InstanHitWeapon=true
bEnableCompVisionOptimization=true
UseAvatarComponent2=false
UseAvatarComponent=true
bUsePoseStateOfflineCheck=true
bEnableDebugServiceInfo=false
bCausedByWorld=99,999
CharacterAnimEventDelegate=Max
OnPushDamageDynamicDelegate=Max
OnTakeDamageDynamicDelegate=Max
bScaleMomentumByMass=99,999
bRadialDamageVelChange=false
DamageImpulse=99,999
DestructibleImpulse=99,900000
DestructibleDamageSpreadScale=99,900000
DamagePartJudgment=99,900000

[/Script/ShadowTrackerExtra.AntiCheatConfig]
nill
null
exit
exits

[/Script/ShadowTrackerExtra.SaveGame]
nill
null
exit
exits

[/Script/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*]
14680=true
14685=true

[WeaponRecoilConfig]
r.VerticalRecoilMin=0
r.VerticalRecoilMax=0
r.VerticalRecoilRecoveryMin=0
r.VerticalRecoilVariation=0
r.VerticalRecoveryModifier=0
r.VerticalRecoveryClamp=0
r.VerticalRecoveryMax=0
r.LeftMax=0
r.RightMax=0
r.VehicleRecoilScalar=0

[/Script/ShadowTrackerExtra.PartHitComponent]
UpdateHitBoxDeltaTime=true
bActivePartHit=true
bDebugCollisionLine=true
GetCurHitPartJugementType=99×10000(true)
HitPartJugementTypeWeapon=10000(true)
UpdateHitBoxDeltaTime=true

[/Script/ShadowTrackerExtra.STCharacterMovementComponent]
UseVelocityDirMinSpeed=9.9f
JumpFloorZ=1200

[/Script/ShadowTrackerExtra.DamageType]
DestructibleDamageSpreadScale=99,90000(true)
DamageImpulse=99,90000(true)
bRadialDamageVelChange=10000
bCausedByWorld=true
bScaleMomentumByMass=10000(true)
bScaleWeaponshotsMomentumByMass=9000(true)
r.DestructibleDamageSpreadScale=9.9f
bDestructibleImpulse=99.9f
bDamageFalloff=100.0f
bDamageImpulse=9.9f
r.RadialDamageVelChange=true
r.CausedByWorld=true
r.ScaleMomentumByMass=true
r.CausedByWorld=9999
r.ScaleMomentumByMass=9999
r.RadialDamageVelChange=9999
r.DamageImpulse=999.1
HitPartDestructibleDamageSpreadScale=9.9f

[/Script/ShadowTrackerExtra.AlTargetInViewOffset]
bTargetInViewDueToOffset=999999

[/Script/ShadowTrackerExtra.STExtraPlayerController]
+AutoScopeAimTraceDistance=90000.0f
+CanMoveCDTime=0.00009
+CanSprintCDTime=0.000009
+SwitchPoseCDTime=0.000009
+MovealbeSwitchPoseTime=0.000009
+bIsAutoAimEnabled=true
+bIsMeleeAutoAimEnabled=true
+IsDeadForLogout=false
+bIsAutoAimOnlyInTouch=true
+bIsAutoAimOnlyOnFire=true
+bMoveInMiniMap=true
+bAutoSprint=true
+IsCurrentSpectatorFreeView=0
+isPressingBtn_AimAndFire=true
+DiedisableInput=false
+bShowWhoObservingMe=0
+IsCharacterInitFlushStreaming=true
+IsAutoGetCircleInfo=true
+bEnableOBBulletTrackEffect=true
+bEnableOBBulletTrackEffectSetting=true
+bAddMovementTickInSpect=false
+IsCanViewEnemy=true
+AutoSelectViewTarget=true

[/Script/ShadowTrackerExtra.MovementComponent]
GetMaxSpeed=99+999

[/Script/ShadowTrackerExtra.ClothPhysicsProperties_Legacy]#DVGENT
GravityScale=120.0f

[/Script/ShadowTrackerExtra.STExtraGameInstance]
+SwitchesInMaps=(MapName="shooting_range4",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="PUBG_Forest",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="PUBG_Desert",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="PUBG_Savage_Main",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="DihorOtok_Main",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="TD_Logging_Camp_Main",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="PVE_Infection_main",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="HP_City_Main",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="TD_Ruins_Half",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="TD_Factory_Depot_Mian",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="VehicleBattle_TDM_PUBG_Forest",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="SocialIsland_Main",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="SocialIsland_Private_Main",Switches=((Key="t.MaxFPS",Value="60")))
+RenderStyleParamsInMaps=(DynamicStyleName=ERenderDynamicStyle::Default, PostProcessParams=("ColorSaturation|(X=2.300000,Y=2.300000,Z=2.300000,W=2.300000)"), ACESParams=(TintColor=(R=1.000000,G=1.000000,B=1.000000,A=1.000000),Bright=0.500000,Gray=1.00000,ShoulderStrength=2.330000,ToeStrength=0.140000,LinearStrength=0.500000,LinearAngle=0.060000))
+MobileMSAAOpenConfig=(RenderKey="r.ACESStyle", RenderValue=5)
+MobileMSAAOpenConfig=(RenderKey="t.MaxFPS", RenderValue=60)
+MobileMSAACloseConfig=(RenderKey="r.ACESStyle", RenderValue=5)
+MobileMSAACloseConfig=(RenderKey="t.MaxFPS", RenderValue=60)

[/Script/ShadowTrackerExtra.STExtraPlayerController]
+SwitchesInMaps=(MapName="shooting_range4",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="PUBG_Forest",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="PUBG_Desert",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="PUBG_Savage_Main",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="DihorOtok_Main",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="TD_Logging_Camp_Main",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="PVE_Infection_main",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="HP_City_Main",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="TD_Ruins_Half",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="TD_Factory_Depot_Mian",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="VehicleBattle_TDM_PUBG_Forest",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="SocialIsland_Main",Switches=((Key="t.MaxFPS",Value="60")))
+SwitchesInMaps=(MapName="SocialIsland_Private_Main",Switches=((Key="t.MaxFPS",Value="60")))